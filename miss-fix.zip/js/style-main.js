$(document).ready(function(){
    $('.on_search').click(function(e) {
        e.preventDefault();
        if ($('#form_search').css('display') == 'none') {
            $('#form_search').show();
        }
        else {
            $('#form_search').hide();
        }
    });
});

//-------------render_size--------------------//

$( window ).load(function() {
    render_size();
    var url = window.location.href;
    $('.menu-item  a[href="' + url + '"]').parent().addClass('active');
});

$( window ).resize(function() {
    render_size();
});
function render_size(){

    var h_107407 = $('.h_107407 img').width();
    $('.h_107407 img').height( 1.07407 * parseInt(h_107407));
}


